package com.emp.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.emp.exception.EmployeeException;

public class DBConnection {
	
	public DBConnection() {
		
	}

	public static Connection getConnection() throws EmployeeException
	{
		Connection con;
		String url;
		String user;
		String pass;
		try {
			con = null;
			Properties props=new Properties();
			FileReader fr=new FileReader("resources/jdbc.properties");
			props.load(fr);
			 url = props.getProperty("jdbcurl");
			 user = props.getProperty("user");
			 pass = props.getProperty("pass");
			 /*String url = "jdbc:oracle:thin:@localhost:1521:xe";
				String user = "system";
				String pass = "orcl11g";
			
					try {*/
			con = DriverManager.getConnection(url, user, pass);
			} catch (FileNotFoundException e) {
				throw new EmployeeException("jdbc.properties not found");
			} catch (IOException e) {
				throw new EmployeeException("unable to read properties");
		
			}
	catch (SQLException e) {
		throw new EmployeeException("unable to insert");
			}
			return(con);
	}
}
