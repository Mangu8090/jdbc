package com.emp.pl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceImp1;

public class EMSApp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("1. Add Employee\n2.View All Employees\n3.delete employee4.view employee by id");
		int n= sc.nextInt();
		switch(n){
		
		case 1:
		System.out.println("Enter employee name");
		String name=sc.next();
		System.out.println("Enter sal");
		int sal=sc.nextInt();
		
		EmployeeBean bean=new EmployeeBean();
		bean.setEname(name);
		bean.setEsal(sal);
		EmployeeService service=new EmployeeServiceImp1();
		try{
			
		int id=service.addEmployee(bean);
		System.out.println("Employee added success id"+id);
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		
		
		case 2:
			EmployeeService service1=new EmployeeServiceImp1();
			try {
				List<EmployeeBean> EmpList = new ArrayList<EmployeeBean>();
				EmpList = service1.viewAllEmployees();
					Iterator<EmployeeBean> i = EmpList.iterator();
					while (i.hasNext()) {
						System.out.println(i.next());
					}
				} catch(EmployeeException e)
				{
					e.printStackTrace();

				}
			break;
			
		case 3:
			EmployeeService service2=new EmployeeServiceImp1();
			System.out.println("Enter id");
			int id=sc.nextInt();
			//EmployeeBean bean1=new EmployeeBean();
			//bean1.setEmpid(id);
			try{
				
			service2.deleteEmployee(id);
			
			}
			catch(EmployeeException e)
			{
				e.printStackTrace();
			}
		}
	}
}



				

