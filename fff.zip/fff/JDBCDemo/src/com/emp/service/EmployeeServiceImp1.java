package com.emp.service;

import java.util.List;


import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDao;
import com.emp.dao.EmployeeDaoImp1;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImp1 implements EmployeeService{
	 
	
	public int addEmployee(EmployeeBean bean)throws EmployeeException{
		EmployeeDao employeeDao=new EmployeeDaoImp1();
		int id=employeeDao.addEmployee(bean);
	return id;
	}
	
	public List<EmployeeBean>viewAllEmployees() throws EmployeeException {
		EmployeeDao employeeDao=new EmployeeDaoImp1();
		List<EmployeeBean> EmpList=employeeDao.viewAllEmployees();
		return EmpList;
	}
	
	public void deleteEmployee(int id) throws EmployeeException{
		EmployeeDao employeeDao=new EmployeeDaoImp1();
		employeeDao.deleteEmployee(id);
		
	}

}
