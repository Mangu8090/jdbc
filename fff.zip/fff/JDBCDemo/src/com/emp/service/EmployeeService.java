package com.emp.service;

import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface EmployeeService {

	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	public List<EmployeeBean>viewAllEmployees() throws EmployeeException;
	public void deleteEmployee(int id) throws EmployeeException;
}
