package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImp1 implements EmployeeDao{
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		Connection con=null;
		int id=0;
		String cmd="insert into emp_tbi(empid,ename,empsalary) values(?,?,?)";
		
		try {
			con=DBConnection.getConnection();
			id=generateEmployeeId();
			PreparedStatement pstmt=con.prepareStatement(cmd);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getEname());
			pstmt.setInt(3, bean.getEsal());
			
			int n=pstmt.executeUpdate();
			System.out.println(n);
		} catch (Exception e) {
				
			throw new EmployeeException("unable to insert");
			
		}
		return id;
	}
	
	public void deleteEmployee(int id) throws EmployeeException{
		Connection con=null;
		int id1=0;
		String cd="delete from emp_tbi where empid="+id;
		try {
			con=DBConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet rst=stmt.executeQuery(cd);
			
		} catch (Exception e) {
				
			throw new EmployeeException("unable to delete");
			
		}
		System.out.println("Row deleted");
	}
	
	public List<EmployeeBean>viewAllEmployees() throws EmployeeException {
		Connection con=null;
		String cm="select empid,ename,empsalary from emp_tbi";
		List<EmployeeBean> EmpList=new ArrayList<EmployeeBean>();
		try {
			con=DBConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet rst=stmt.executeQuery(cm);

			while(rst.next())
			{	
				EmployeeBean bean=new EmployeeBean();
				bean.setEmpid(rst.getInt(1));
				bean.setEname(rst.getString(2));
				bean.setEsal(rst.getInt(3));
				EmpList.add(bean);
			}
			return EmpList;
			
		} catch (Exception e) {
				
			throw new EmployeeException("unable to view");
		}
		}

public int generateEmployeeId() throws EmployeeException{
	int id=0;
	Connection con=null;
	String qry="select es.nextval from dual";
	try {
		con=DBConnection.getConnection();
		Statement stmt=con.createStatement();
		ResultSet rst=stmt.executeQuery(qry);
		rst.next();
		id=rst.getInt(1);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return id;
}
	
	
}
